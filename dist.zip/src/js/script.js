function toggleNav() {
  const nav = document.getElementById("myTopnav");
  nav.classList.toggle("responsive");
}

function filterSelection(c) {
  const boxes = document.getElementsByClassName("box");
  const headings = document.querySelectorAll("#spolier h2");

  Array.from(boxes).forEach((box) => {
    box.style.display = c === "all" || box.classList.contains(c) ? "block" : "none";
  });

  headings.forEach((h2) => {
    h2.style.display = (c === "all" ? h2.classList.contains("all") : h2.classList.contains(c))
      ? "block"
      : "none";
  });
}

document.addEventListener("DOMContentLoaded", () => {
  filterSelection("all");
  const tabs = document.getElementById("tabs").getElementsByClassName("btn");

  Array.from(tabs).forEach((tab) => {
    tab.addEventListener("click", function () {
      Array.from(tabs).forEach((t) => t.classList.remove("active"));
      this.classList.add("active");
    });
  });
});

// Add active class to the current button (highlight it)
var filterTabs = document.getElementById("menu");
var tab = filterTabs.getElementsByClassName("btn");
for (var i = 0; i < tab.length; i++) {
  tab[i].addEventListener("click", function () {
    var current = document.getElementsByClassName("active");
    Array.from(current).forEach((x) => x.classList.remove("active"));
    this.classList.add("active");
  });
}
